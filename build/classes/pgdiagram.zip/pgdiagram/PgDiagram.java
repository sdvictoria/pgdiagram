/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pgdiagram;

import java.awt.Color;
import java.awt.Point;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

/**
 *
 * @author nospoon
 */
public class PgDiagram {
    
    static String appDir;
    static String dbName = "pmtmgr";  // usrmgr, drwmgr, cumulus2, cutomer_manager
    static String schema = "pmtmgr";   // cumu2_ao, usrmgr, customer_manager, pmtmgr

    public static void main(String[] args) {
        PgDiagram app = new PgDiagram();
        app.go();
    }
   
    void go() {
        appDir = new File(".").getAbsolutePath();
        appDir = appDir.replace("\\", "/");
        if (appDir.endsWith("/.")) {
            appDir = appDir.substring(0, appDir.length()-2);
        }
        
        if (false) {          
            Model model = createModelFromDB(dbName, schema);   
            if (true) {
                try {
                Connection conn = getConnectionPostgres(dbName);
                updateModel(model, schema, conn);
                conn.close();
                } catch (Exception ex) { ex.printStackTrace(); }
            }
        }

        FraMain fra = new FraMain();
        fra.loadModel();
//        fra.model = model;
//        fra.canvas.setModel(model);
    }

    public static Model toModel(String filename) {
        Model model = new Model();
        try {            
            FileReader reader = new FileReader(filename);            
            Properties p = new Properties();
            p.load(reader);
            
            for (int table_idx=0; ;table_idx++) {
                String tableKey = "table_" + table_idx + ".";
                String tableName = p.getProperty(tableKey + "name");
                if (tableName==null) {
                    break;
                }
                Table table = new Table(tableName);
                model.add(table);
                for (int column_idx=0; ;column_idx++) {
                    String columnKey = tableKey + "column_" + column_idx + ".";
                    String columnName = p.getProperty(columnKey + "name");
                    if (columnName==null) {
                        break;
                    }
                    Column c = table.addCol(columnName, column_idx);
                    String actualDistinctCount_str = p.getProperty(columnKey + "actualDistinctCount");
                    if (actualDistinctCount_str!=null) {
                        try {
                            c.actualDistinctCount = Long.parseLong(actualDistinctCount_str);
                        } catch (Exception ex) {
                            ex.printStackTrace();
                        }
                    }
                    if (c.actualDistinctCount>0) {                        
                        c.distinctValues = readDistinctValuesFromFile(appDir + "/" + getColumnFileName(c));
                    }                    
                }
                
                for (int pk_idx=0; ;pk_idx++) {               
                    String pks = p.getProperty(tableKey + "pk_" + pk_idx);
                    if (pks==null) {
                        break;
                    }
                    String[] arr = toStringArray(pks, ",");
                    table.addPK(arr);
                }     
                
                for (int uk_idx=0; ;uk_idx++) {               
                    String uks = p.getProperty(tableKey + "unique_" + uk_idx);
                    if (uks==null) {
                        break;
                    }
                    String[] arr = toStringArray(uks, ",");
                    table.addUniqueKey(arr);
                }    
                
                for (int ik_idx=0; ;ik_idx++) {               
                    String iks = p.getProperty(tableKey + "index_" + ik_idx);
                    if (iks==null) {
                        break;
                    }
                    String[] arr = toStringArray(iks, ",");
                    table.addIndex(arr);
                }     
                
                for (int fk_idx=0; ;fk_idx++) { 
                    String fkKey = tableKey + "fk_" + fk_idx + ".";
                    String fkFromTable = p.getProperty(fkKey + "fromTable");
                    if (fkFromTable==null) {
                        break;
                    }
                    String fkFromCols[] = toStringArray(p.getProperty(fkKey + "fromCols"), ",");
                    String fkToTable = p.getProperty(fkKey + "toTable");
                    String fkToCols[] = toStringArray(p.getProperty(fkKey + "toCols"), ",");                    
                    List<Point> linePoints = toPointList(p.getProperty(fkKey + "linePoints"));  
                    String colorCode = p.getProperty(fkKey + "lineColor", "");
                    Color lineColor = Color.black;
                    try {
                        colorCode = colorCode.trim();
                        colorCode = colorCode.toUpperCase();
                        colorCode = colorCode.replaceAll("0X", "");
                        if (colorCode.length()==8) {
                            colorCode = colorCode.substring(0, 6);
                        }
                        if (colorCode.length()==6) {
                            lineColor = new Color(Integer.parseInt(colorCode, 16));
                        }
                    } catch ( Exception ex) { ex.printStackTrace(); }
                    ForeignKey fk = model.addFK(fkFromTable, fkFromCols, fkToTable, fkToCols, linePoints, lineColor);
                    String point_str = p.getProperty(fkKey + "startAnchor.Offset");
                    Point point = stringToPoint(point_str);
                    if (point!=null) {
                        fk.startAnchorOffset.offset = point;
                    }
                    point_str = p.getProperty(fkKey + "endAnchor.Offset");
                    point = stringToPoint(point_str);
                    if (point!=null) {
                        fk.endAnchorOffset.offset = point;
                    }
                    
                    String enum_str = p.getProperty(fkKey + "startAnchor.Orientation");
                    if ("RIGHT".equalsIgnoreCase(enum_str)) {
                        fk.startAnchorOffset.orientation = Anchor.AnchorOrientation.RIGHT;
                    }
                    
                    enum_str = p.getProperty(fkKey + "endAnchor.Orientation");
                    if ("RIGHT".equalsIgnoreCase(enum_str)) {
                        fk.endAnchorOffset.orientation = Anchor.AnchorOrientation.RIGHT;
                    }
                }                
                String val = p.getProperty(tableKey + "location");
                Point point = stringToPoint(val);
                if (point!=null) {
                    table.x = point.x;
                    table.y = point.y;
                }                               
                reader.close();
            }
        } catch (Exception ex) { ex.printStackTrace(); }
        return model;
    }
    
    public static Point stringToPoint(String s) {
        Point p = null;
        try {
            String arr[] = toStringArray(s, ",");
            if (arr.length==2) {
                p = new Point(Integer.parseInt(arr[0]), Integer.parseInt(arr[1]));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return p;
    }   
    
    public static void toFileDistincValues(Column col, String filename) {
        try {
            if (col!=null && col.distinctValues!=null && col.distinctValues.size()>0) {
                FileWriter fw = new FileWriter(filename);        
                for (String s:col.distinctValues) {
                    fw.write(s + "\n");
                }
                 fw.close();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public static List<String> readDistinctValuesFromFile(String filename) {
        List<String> list = new ArrayList();
        try {
            File f = new File(filename);
            if (f.isFile() && f.canRead()) {
                BufferedReader reader = new BufferedReader(new FileReader(f));       
                String line = reader.readLine();
                while (line!=null) {
                    list.add(line);                
                    line = reader.readLine();
                }
                reader.close();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return list;
    }
    
    public static void toFile(Model model, String filename) {
        try {
            FileWriter fw = new FileWriter(filename);        
            Collection<String> coll = model.tables.keySet();
            String arr[] = coll.toArray(new String[0]);
            Arrays.sort(arr);

            int table_idx = -1;
            for (String tableName:arr) {
                table_idx++;
                Table table = model.tables.get(tableName);
                String tableKey = "table_" + table_idx + ".";
                fw.write(tableKey + "name=" + table.name + "\n");
                Column[] cols = table.getColumnsInOrder();
                int column_idx = -1;
                for (Column c:cols) {
                    column_idx++;
                    String columnKey = tableKey + "column_" + column_idx + ".";
                    if (c==null) {
                        fw.write(columnKey + "name=null\n");
                    }
                    else {
                        fw.write(columnKey + "name=" + c.name + "\n");
                        if (c.actualDistinctCount>0) {
                            fw.write(columnKey + "actualDistinctCount=" + c.actualDistinctCount + "\n");
                            toFileDistincValues(c, appDir + "/" + getColumnFileName(c));
                        }                                                        
                    }
                }

                int pk_idx=-1;
                for (String[] pkCols:table.primaryKeys) {
                    pk_idx++;
                    fw.write(tableKey + "pk_" + pk_idx + "=" + toCommaSeperatedString(pkCols) + "\n");
                }
                int uk_idx=-1;
                for (String[] ukCols:table.uniqueKeys) {
                    uk_idx++;
                    fw.write(tableKey + "unique_" + uk_idx + "=" + toCommaSeperatedString(ukCols) + "\n"); 
                }            
                int ik_idx=-1;
                for (String[] idx:table.indices) {
                    ik_idx++;
                    fw.write(tableKey + "index_" + ik_idx + "=" + toCommaSeperatedString(idx) + "\n"); 
                }            

                List<ForeignKey> tableFKs = model.getKFList(tableName);
                int fk_idx=-1;
                for (ForeignKey fk:tableFKs) {
                    fk_idx++;
                    String fkKey = tableKey + "fk_" + fk_idx + ".";
                    fw.write(fkKey + "fromTable=" + fk.fromTableName + "\n");
                    fw.write(fkKey + "fromCols=" + toCommaSeperatedString(fk.fromCols) + "\n");
                    fw.write(fkKey + "toTable=" + fk.toTableName + "\n");
                    fw.write(fkKey + "toCols=" + toCommaSeperatedString(fk.toCols) + "\n");              
                    // control points
                    fw.write(fkKey + "linePoints=" + toCommaSeperatedString(fk.linePoints) + "\n");  
                    // line color
                    String r = Integer.toHexString(fk.color.getRed());            
                    String g = Integer.toHexString(fk.color.getGreen());
                    String b = Integer.toHexString(fk.color.getBlue());
                    if (r.length()==1) { r = "0" + r; }
                    if (g.length()==1) { g = "0" + g; }
                    if (b.length()==1) { b = "0" + b; }    
                    String colorCode = r+g+b;
                    colorCode = colorCode.toUpperCase();
                    colorCode = "0x"+colorCode;
                    fw.write(fkKey + "lineColor=" + colorCode + "\n");     
                    fw.write(fkKey + "startAnchor.Offset=" + fk.startAnchorOffset.offset.x + "," + fk.startAnchorOffset.offset.y + "\n");     
                    fw.write(fkKey + "startAnchor.Orientation=" + fk.startAnchorOffset.orientation + "\n");     
                    fw.write(fkKey + "endAnchor.Offset=" + fk.endAnchorOffset.offset.x + "," + fk.endAnchorOffset.offset.y + "\n");     
                    fw.write(fkKey + "endAnchor.Orientation=" + fk.endAnchorOffset.orientation + "\n");                         
                }
                fw.write(tableKey + "location=" + table.x + "," + table.y + "\n"); 
            }
            fw.close();
        } catch (Exception ex) {ex.printStackTrace();}            
    }
    static String[] toStringArray(String s, String seperator) {
        if (s==null) {
            return new String[0];
        }
        String arr[] = s.split(seperator);        
        for (int i=0; i<arr.length; i++) {
            arr[i] = arr[i].trim();
        }
        return arr;
    }
    
    static String getColumnFileName(Column c) {
        return schema + "_" + c.table.name + "_" + c.name;
    }
    
    static String toCommaSeperatedString(List<Point> points) {
        StringBuilder buff = new StringBuilder();
        if (points!=null) {
            for (Point p:points) {
                if (buff.length()>0) {
                    buff.append(";");
                }
                buff.append(p.x + "," + p.y);
            }
        }
        return buff.toString();
    }
    
    static List<Point> toPointList(String str) {       
        List<Point> list = new ArrayList();
        if (str!=null) {
            String arr[] = str.split(";");   
            for (String s:arr) {
                String tmp[] = s.split(",");
                if (tmp.length==2) {
                    try {
                        Point p = new Point();
                        p.x = Integer.parseInt(tmp[0]);
                        p.y = Integer.parseInt(tmp[1]);            
                        list.add(p);
                    } catch (Exception ex) {ex.printStackTrace();}
                }
            }
        }
        return list;
    }
    
    static String toCommaSeperatedString(String arr[]) {
        StringBuilder buff = new StringBuilder();
        if (arr!=null) {
            for (String s:arr) {
                if (buff.length()>0) {
                    buff.append(", ");  
                }
                buff.append(s);  
            }
        }
        return buff.toString();
    }
    
    static void fetchDistinctValues(Column c) {
        Connection conn = null;
        Statement st = null;
        ResultSet rs = null;
        try {            
            conn = getConnectionPostgres(dbName);            
            System.out.println("fetching distinct values for " + c.table.name + "." + c.name);
            st = conn.createStatement();
            st.setQueryTimeout(10);
            String sql = "select count(distinct("+ c.name +")) from " +schema+ "." + c.table.name;                
            rs = st.executeQuery(sql);                            
            while (rs.next()) {            
                c.actualDistinctCount = rs.getLong(1);
            }

            if (c.actualDistinctCount<100) {
                List<String> values = new ArrayList();
                sql = "select distinct("+ c.name +") from " +schema+ "." + c.table.name + " order by " + c.name;
                rs = st.executeQuery(sql);                
                while (rs.next()) {            
                    values.add(rs.getString(1));
                }
                c.distinctValues = values;
            }                
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        finally {
            try {
                if (rs!=null) { rs.close(); }
                if (st!=null) { st.close(); }
                if (conn!=null) {conn.close(); }            
            } catch (Exception ex1) {}
        }
    }
    
    void updateModel(Model model, String schema, Connection conn) {
        try {
            for (Table table:model.tables.values()) {
                System.out.println("fetching foreign keys for " +table.name);
                Statement st = conn.createStatement();
                String sql = "select \n" +
                    "    att2.attname as \"child_column\", \n" +
                    "    cl.relname as \"parent_table\", \n" +
                    "    att.attname as \"parent_column\"\n" +
                    "from\n" +
                    "   (select \n" +
                    "        unnest(con1.conkey) as \"parent\", \n" +
                    "        unnest(con1.confkey) as \"child\", \n" +
                    "        con1.confrelid, \n" +
                    "        con1.conrelid\n" +
                    "    from \n" +
                    "        pg_class cl\n" +
                    "        join pg_namespace ns on cl.relnamespace = ns.oid\n" +
                    "        join pg_constraint con1 on con1.conrelid = cl.oid\n" +
                    "    where\n" +
                    "        cl.relname = '"+table.name+"'\n" +
                    "        and ns.nspname = '"+schema+"'\n" +
                    "        and con1.contype = 'f'\n" +
                    "   ) con\n" +
                    "   join pg_attribute att on\n" +
                    "       att.attrelid = con.confrelid and att.attnum = con.child\n" +
                    "   join pg_class cl on\n" +
                    "       cl.oid = con.confrelid\n" +
                    "   join pg_attribute att2 on\n" +
                    "       att2.attrelid = con.conrelid and att2.attnum = con.parent";
                
                ResultSet rs = st.executeQuery(sql);                
                Map<String, List<String>> localTableMap = new HashMap();
                Map<String, List<String>> foreignTableMap = new HashMap();
                while (rs.next()) {            
                    String localColumn = rs.getString("child_column");
                    String parentTable = rs.getString("parent_table");
                    String parentColumn = rs.getString("parent_column");
                    
                    List<String> list = localTableMap.get(parentTable);
                    if (list==null) {
                        list = new ArrayList();
                        localTableMap.put(parentTable, list);
                    }
                    list.add(localColumn);
                    
                    list = foreignTableMap.get(parentTable);
                    if (list==null) {
                        list = new ArrayList();
                        foreignTableMap.put(parentTable, list);
                    }
                    list.add(parentColumn);                                        
                }
                rs.close();
                st.close();
                
                for (String ft:foreignTableMap.keySet()) {
                    List<String> localCols = localTableMap.get(ft);
                    List<String> remoteCols = foreignTableMap.get(ft);
                    
                    String fromCols[] = localCols.toArray(new String[0]);
                    String toCols[] = remoteCols.toArray(new String[0]);                    
                    model.addFK(table.name, fromCols, ft, toCols, null, Color.black);
                }
            }    
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    Model createModelFromDB(String dbName, String schema) {
        Model model = new Model();
        Connection conn = null;
        try {
            conn = getConnectionPostgres(dbName);
            Statement st = conn.createStatement();
            String sql = "SELECT * \n" +
                        "  FROM information_schema.tables\n" +
                        " WHERE table_schema='"+schema+"'\n" +
                        "   AND table_type='BASE TABLE'";
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {            
                model.add(new Table(rs.getString("table_name")));
            }

            rs.close();
            
            if (true) {
                for (Table table:model.tables.values()) {
                    System.out.println("fetching columns for " +table.name);

                    sql = " SELECT DISTINCT\n" +
                            "    a.attnum as num,\n" +
                            "    a.attname as column_name,\n" +
                            "    format_type(a.atttypid, a.atttypmod) as typ,\n" +
                            "    a.attnotnull as notnull\n" +
                            "FROM pg_attribute a \n" +
                            "JOIN pg_class pgc ON pgc.oid = a.attrelid\n" +
                            "WHERE a.attnum > 0 AND pgc.oid = a.attrelid\n" +
                            "AND pg_table_is_visible(pgc.oid)\n" +
                            "AND NOT a.attisdropped\n" +
                            "AND pgc.relname = '"+table.name+"'" +
                            "ORDER BY a.attnum";
                    
                    sql = "select column_name, ordinal_position from information_schema.columns where table_name = '"+table.name+"' order by ordinal_position";

                    rs = st.executeQuery(sql);
                    while (rs.next()) {            
                        table.addCol(rs.getString("column_name"), rs.getInt("ordinal_position")-1);
                    }                            
                }
            }
            
            
            st.close();
            conn.close();
        } catch (Exception ex) {
            ex.printStackTrace();
            if (conn!=null) {
                try { conn.close(); } catch (Exception ex1) { ex1.printStackTrace(); }
            }
        }
        return model;
    }
    Model createTestModel() {
         Model model = new Model();
        
        Table ta = new Table("A");
        ta.addCol("a_pk",0);
        ta.addCol("a_1",1);
        ta.addCol("a_2",2);

        Table tb = new Table("B");
        tb.addCol("b_pk",0);
        tb.addCol("b_1",1);
        tb.addCol("b_2",1);
        
        Table tc = new Table("C");
        tc.addCol("c_pk",0);
        tc.addCol("c_1",1);
        tc.addCol("c_2",1);                
        
        model.add(ta);
        model.add(tb);
        model.add(tc);
        
        Table t = model.getTable("A");
        t.addPK("a_pk");
        t.addIndex("a_1");
        
        t.addUniqueKey("a_2");
        
        t = model.getTable("B");
        t.addPK(new String[] {"b_pk", "b_1"});
        
        t = model.getTable("C");
        t.addPK(new String[] {"c_pk", "c2"});
        
        String from_fields[] = {"b_pk"};
        String to_fields[] = {"a_pk"};
        model.addFK("B", from_fields, "A", to_fields, null, Color.black);
        String from_fields1[]  = new String[] {"c_pk"};
        String to_fields1[] = new String[] {"a_pk"};

        model.addFK("C", from_fields1, "A", to_fields1, null, Color.black); // indirect ref to b   
        return model;
    }
    
    public static Connection getConnectionPostgres(String dbName) {

                String url = null;
                String user = null;
                String pwd = null;
                
//                    case UK_VDC_TEST:				
//                            url = "jdbc:postgresql://sqlst2testpostgress002.local.sqills.com:5444";
//                            user = "enterprisedb";
//                            pwd = "sqills2014";
//                            break;	
//                    case NOFTL1:
                            //url = "jdbc:postgresql://gnlasdstppas856.nl.novamedia.com:5444"; // noftl4
                            url = "jdbc:postgresql://gnlasdstppas813.nl.novamedia.com:5444"; // noftl1
                            user = "enterprisedb";
                            pwd = "enterprisedb";                            
                        			
                Connection conn = null;
                try {
                        Class.forName("org.postgresql.Driver");                        
                        conn = DriverManager.getConnection(url + "/" + dbName, user, pwd);						
                } catch (Exception e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                }				
                return conn;
        }    
}
