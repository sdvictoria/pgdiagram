/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pgdiagram;

import java.awt.Canvas;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 *
 * @author nospoon
 */
public class MoveDiagramMouseHandler extends MouseAdapter {
    
    CnvDiagram cnv;
    
    MoveDiagramMouseHandler(CnvDiagram cnv) {
        this.cnv = cnv;
    }
    
    int mousePressX, mousePressY;
    int oldTableX, oldTableY;
    Point oldControlPoint = new Point();
    Point oldAnhorOffset = new Point();
    public CnvDiagram.HitTestResult hitTestResult = null;    
    
   @Override
    public void mousePressed(MouseEvent e) {
        boolean repaint = false;
        mousePressX = e.getX();
        mousePressY = e.getY();
        hitTestResult = cnv.hitTest(e.getX(), e.getY());
        if (hitTestResult.table!=null) {
            oldTableX = hitTestResult.table.x;
            oldTableY = hitTestResult.table.y;
            
            if (hitTestResult.column!=null) {
                // PgDiagram.fetchDistinctValues(hitTestResult.column);
            }            
        }        
        
        if (hitTestResult.hitForeignKey!=null) {
            String r = Integer.toHexString(hitTestResult.hitForeignKey.color.getRed());            
            String g = Integer.toHexString(hitTestResult.hitForeignKey.color.getGreen());
            String b = Integer.toHexString(hitTestResult.hitForeignKey.color.getBlue());
            if (r.length()==1) { r = "0" + r; }
            if (g.length()==1) { g = "0" + g; }
            if (b.length()==1) { b = "0" + b; }    
            String colorCode = "0x"+r+g+b;
            colorCode = colorCode.toUpperCase();
            cnv.fraMain.txtColor.setText(colorCode);
            if (e.isControlDown() && !e.isShiftDown()) {
                // hitTestResult.hitForeignKey.addControlPoint(hitTestResult.foreignKeyLineSection-1, e.getPoint());
                Point np = new Point(e.getPoint());
                System.out.println("hitTestResult.foreignKeyLineSection: " + hitTestResult.foreignKeyLineSection);
                hitTestResult.hitForeignKey.addControlPoint(hitTestResult.foreignKeyLineSection+1, np);
                hitTestResult.controlPoint = np;
                repaint = true;
            }            
        }
        
        if (hitTestResult.controlPoint!=null) {
            if (e.isControlDown() && e.isShiftDown()) {                
                hitTestResult.hitForeignKey.removeControlPoint(hitTestResult.controlPoint);
                hitTestResult.controlPoint = null;
                repaint = true;
            }
            else {
                oldControlPoint.x = hitTestResult.controlPoint.x;
                oldControlPoint.y = hitTestResult.controlPoint.y;                
            }
        }
        
 
        if (hitTestResult.anchor != null) {
            oldAnhorOffset.x = hitTestResult.anchor.offset.x;
            oldAnhorOffset.y = hitTestResult.anchor.offset.y;
        }
        
        if (repaint) {
            cnv.refresh();
        }        
    }
    
  @Override
    public void mouseDragged(MouseEvent e) {
        boolean repaint = false;
        int diffX = e.getX() - mousePressX;
        if (diffX>100) {
            //diffX++;
        }
        int diffY = e.getY() - mousePressY;
        if (hitTestResult.table!=null) {
            int newX = oldTableX + diffX;
            int newY = oldTableY + diffY;
            boolean grid = true;
            if (grid) {
                newX =  (newX / 10) * 10;
                newY =  (newY / 10) * 10;
            }
            hitTestResult.table.x = newX;
            hitTestResult.table.y = newY;  
            repaint = true;
        }    
        else if (hitTestResult.anchor!=null) {
            int anchorX = diffX + oldAnhorOffset.x;
            if (hitTestResult.anchor.orientation==Anchor.AnchorOrientation.RIGHT) {
                anchorX = diffX + oldAnhorOffset.x;
            }
            int anchorY = oldAnhorOffset.y + diffY;
            
            Table table = cnv.model.getTable(hitTestResult.anchor.startAnchor?hitTestResult.hitForeignKey.fromTableName:hitTestResult.hitForeignKey.toTableName);
            if (table!=null) {
                if (hitTestResult.anchor.orientation==Anchor.AnchorOrientation.RIGHT && e.getX() < table.x) {
                    hitTestResult.anchor.flip();
                    mousePressX -= table.totalRect.width;
                    mouseDragged(e);
                    return;
                }
                if (hitTestResult.anchor.orientation==Anchor.AnchorOrientation.LEFT && e.getX() > table.x + table.totalRect.width) {
                    hitTestResult.anchor.flip();
                    mousePressX += table.totalRect.width;
                    mouseDragged(e);
                    return;                        
                }
            }            
            
            boolean grid = true;
            if (grid) {
                if (Math.abs(anchorX) < 20) {
                    anchorX = (anchorX / 2) * 2;
                }
                else {
                    anchorX = (anchorX / 10) * 10;
                }
                anchorY = (anchorY / 2) * 2;                
//                if (hitTestResult.anchor.orientation==Anchor.AnchorOrientation.RIGHT) {                
//                    anchorX = Math.max(anchorX, 0);                
//                }
//                else {
//                    anchorX = Math.min(anchorX, 0);
//                }
                anchorY = Math.max(anchorY, -10);
                anchorY = Math.min(anchorY, 10);
            }
            hitTestResult.anchor.offset.x = anchorX;
            hitTestResult.anchor.offset.y = anchorY;
            repaint = true;
        }         
        else if (hitTestResult.controlPoint!=null) {
            hitTestResult.controlPoint.x = oldControlPoint.x + diffX;
            hitTestResult.controlPoint.y = oldControlPoint.y + diffY;                       
            boolean grid = true;
            if (grid) {
                hitTestResult.controlPoint.x =  (hitTestResult.controlPoint.x / 10) * 10;
                hitTestResult.controlPoint.y =  (hitTestResult.controlPoint.y / 10) * 10;
            }
            repaint = true;
        }
        if (repaint) {
            cnv.refresh();
        }    
    }
    
    @Override
    public void mouseMoved(MouseEvent e) {
        //System.out.println("mouseMoved");
        cnv.hitTest(e.getX(), e.getY());
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        //System.out.println("mouseClicked");
    }    

    @Override
    public void mouseReleased(MouseEvent e) {
        //System.out.println("mouseReleased");
        hitTestResult = null;
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        //System.out.println("mouseEntered");
    }

    @Override
    public void mouseExited(MouseEvent e) {
        //System.out.println("mouseExited");
    }      
    
    
}
