/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pgdiagram;

import java.awt.Color;
import java.awt.Point;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author nospoon
 */
public class ForeignKey {
    String fromTableName, toTableName;
    String fromCols[], toCols[];
    
    int order;
    // --- gui
    public List<Point> linePoints = new ArrayList();
    public Color color = Color.black;
    public Anchor startAnchorOffset = new Anchor(true);
    public Anchor endAnchorOffset = new Anchor(false);    
    
    public ForeignKey(String fromTableName, String[] fromCols, String toTableName, String[] toCols, int order) {        
        this.fromTableName = fromTableName;
        this.fromCols = fromCols;
        this.toTableName = toTableName;
        this.toCols = toCols;
        this.order = order;
        linePoints.add(new Point());
        linePoints.add(new Point());
        color = new Color(0xFF00FF);
    }
    
    public void setStartPoint(Point p) {
//        if (linePoints.size()==0) {
//            linePoints.add(new Point());
//        }
        linePoints.set(0, p);
    }

    public void setEndPoint(Point p) {
        linePoints.set(linePoints.size()-1, p);
    }    
    
    public void allignYAtStart() {
        if (linePoints.size()>2) {
            linePoints.get(1).y = linePoints.get(0).y;
        }
    }
    
    public void allignYAtEnd() {
        if (linePoints.size()>2) {
            linePoints.get(linePoints.size()-2).y = linePoints.get(linePoints.size()-1).y;
        }        
    }
    
    public void addControlPoint(int lineSectionIdx, Point p) {
        linePoints.add(lineSectionIdx,p);
    }
    
    public void removeControlPoint(Point p) {
        if (linePoints.size()>2) {
            if (linePoints.get(0)==p || linePoints.get(linePoints.size()-1)==p) {
                
            }
            else {
                linePoints.remove(p);
            }
        }
    }        
}
