/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pgdiagram;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Stroke;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.List;
import javax.swing.JPanel;

/**
 *
 * @author nospoon
 */
public class CnvDiagram extends JPanel {
    FraMain fraMain;
    Model model;
    MoveDiagramMouseHandler moveModeMouseHandler;

    
    CnvDiagram(FraMain fra) {
        this.fraMain = fra;
        moveModeMouseHandler = new MoveDiagramMouseHandler(this);
        this.addMouseListener(moveModeMouseHandler);
        this.addMouseMotionListener(moveModeMouseHandler);
    }
    
    public void setModel(Model m) {
        this.model = m;
    }
    
    @Override
    public void paint(Graphics g_) {
        super.paint(g_);
        int widthFactor = 3;
        Graphics2D g = (Graphics2D) g_;        
        if (model!=null) {
            for (Table table:model.tables.values()) {
                drawTable(table, g);
            }
            
            for (List<ForeignKey> fkList:model.foreignKeys.values()) {
                for (ForeignKey fk:fkList) {
                    Table fromTable = model.getTable(fk.fromTableName);
                    Table toTable = model.getTable(fk.toTableName);
                    
                    Point cpFrom = new Point();
                    Point cpTo = new Point();                    
                    int minY = Integer.MAX_VALUE;
                    int maxY = Integer.MIN_VALUE;
                    
                    g.setColor(fk.color);
                    for (String from:fk.fromCols) {
                        Rectangle fromRect = fromTable.getColumnRect(from);
                        if (fromRect==null) {
                            fromRect = fromTable.getColumnRect(from);
                        }
                        if (fromRect==null) {
                            int a = 99;
                        }
                        
                        fromTable.addTableOffsetTorect(fromRect);
                        if (fromRect!=null) {                            
                            int x1 = fromRect.x + (fk.startAnchorOffset.orientation==Anchor.AnchorOrientation.LEFT?-1:fromRect.width+1);
                            int y1 = fromRect.y + fromRect.height/2 + fk.startAnchorOffset.offset.y;
                            int x2 = x1 + fk.startAnchorOffset.offset.x;
                            int y2 = y1;
                            
                            g.drawLine(x1, y1, x2, y2);
                            cpFrom.x += x2;
                            cpFrom.y += y2;
                            
                            minY = Math.min(minY, y1);
                            minY = Math.min(minY, y2);
                            maxY = Math.max(maxY, y1);
                            minY = Math.min(minY, y2);
                        }
                    }
                    
                    cpFrom.x /= fk.fromCols.length;
                    cpFrom.y /= fk.fromCols.length;

                    g.fillRect(cpFrom.x-(fk.fromCols.length*widthFactor)/2, minY, fk.fromCols.length*widthFactor, Math.abs(maxY-minY)+1);
                    
                    minY = Integer.MAX_VALUE;
                    maxY = Integer.MIN_VALUE;
                    
                    for (String to:fk.toCols) {
                        Rectangle toRect = toTable.getColumnRect(to);
                        toTable.addTableOffsetTorect(toRect);
                        if (toRect!=null) {
                            int x1 = toRect.x + (fk.endAnchorOffset.orientation==Anchor.AnchorOrientation.LEFT?-1:toRect.width+1);
                            int y1 = toRect.y + toRect.height/2 + fk.endAnchorOffset.offset.y;
                            int x2 = x1 + fk.endAnchorOffset.offset.x;
                            int y2 = y1;                            
                            
                            g.drawLine(x1, y1, x2, y2);
                            // arrow
                            int arrow_sz = 7;
                            int x3 = x1+ (fk.endAnchorOffset.orientation==Anchor.AnchorOrientation.LEFT?-arrow_sz:+arrow_sz);
                            int x4 = x1+ (fk.endAnchorOffset.orientation==Anchor.AnchorOrientation.LEFT?-arrow_sz:+arrow_sz);
                            int y3 = y2-arrow_sz;
                            int y4 = y2+arrow_sz;
                            
                            int x[] = new int[4];
                            int y[] = new int[4];
                            
                            x[0] = x1;
                            x[1] = x3;
                            x[2] = x4;

                            y[0] = y2;
                            y[1] = y3;
                            y[2] = y4;
                            
                            g.fillPolygon(x,y, 3);
                            
                            cpTo.x += x2;
                            cpTo.y += y2;
                            
                            minY = Math.min(minY, y1);
                            minY = Math.min(minY, y2);
                            maxY = Math.max(maxY, y1);
                            minY = Math.min(minY, y2);                            
                            
                        }                    
                    }
                    
                    cpTo.x /= fk.toCols.length;
                    cpTo.y /= fk.toCols.length;
                    
                    // System.out.println("22:" + 1+(fk.fromCols.length-1)*widthFactor);
                    g.fillRect(cpTo.x-(fk.toCols.length*widthFactor)/2, minY, fk.toCols.length*widthFactor, Math.abs(maxY-minY)+1);
                    // g.drawLine(cpTo.x, minY, cpTo.x, maxY);  
                    Stroke orgStroke = g.getStroke();
                    Stroke stroke = new BasicStroke(1+(fk.fromCols.length-1)*widthFactor);
                    g.setStroke(stroke);
                    
                    // g.drawLine(cpFrom.x, cpFrom.y, cpTo.x, cpTo.y);
                    g.setStroke(orgStroke);
                    
                    fk.setStartPoint(cpFrom);
                    fk.setEndPoint(cpTo);
                    Point lastPoint = null;
                    for (Point p:fk.linePoints) {
                        g.setStroke(stroke);
                        g.setColor(fk.color);
                        if (lastPoint!=null) {
                            g.drawLine(p.x, p.y, lastPoint.x, lastPoint.y);
                        }
                        int halfSideSz = 2;
                        g.setStroke(orgStroke);
                        g.setColor(Color.green);
                        g.fillRect(p.x-halfSideSz, p.y-halfSideSz, halfSideSz*2, halfSideSz*2);
                        halfSideSz = 4;
                        g.drawRect(p.x-halfSideSz, p.y-halfSideSz, halfSideSz*2, halfSideSz*2);
                        lastPoint = p;
                    }
                    g.setStroke(orgStroke);
                }
            }
        }
    }
    
    void drawTable(Table table, Graphics2D g) {   
        
        int ascent = g.getFontMetrics().getAscent();
        
        Rectangle headerRect = table.getHeaderRect(table);
        int offsetX = 0;
        int offsetY = headerRect.y + headerRect.height;
        List<Rectangle> columnsRect = table.getColumnsRect(table, offsetX, offsetY);
        Column[] orderedColumns = table.getColumnsInOrder();
        
        Rectangle totalRect = table.getTotalRect();

        // draw
        int xOffset = table.x;
        int yOffset = table.y;
        g.translate(xOffset, yOffset);
        g.setColor(FraMain.colorTableHeader);
        g.fillRect(headerRect.x, headerRect.y, headerRect.width, headerRect.height);
        g.setColor(FraMain.colorTableName);
        g.drawString(table.name, headerRect.x, headerRect.y+ascent);
                
        int idx = -1;
        for (Rectangle r:columnsRect) {        
            idx++;
            Column col = orderedColumns[idx];
            if (col!=null) {                
                g.setColor(idx%2==0?FraMain.colorColumnRowEven:FraMain.colorColumnRowOdd);
                g.fillRect(r.x, r.y, r.width, r.height);
                g.setColor(FraMain.colorColumnFont);
                if (col.name!=null) {
                    g.drawString(col.name, r.x, r.y+ascent);
                }
            }
        }        
        g.setColor(Color.green);
        g.drawRect(totalRect.x, totalRect.y, totalRect.width, totalRect.height);
        g.translate(-xOffset, -yOffset);
    }

    HitTestResult hitTest(int x, int y) {
        
        HitTestResult hit = new HitTestResult();

        for (Table table:model.tables.values()) {
            Rectangle rect = table.getTotalRect();
            rect.x += table.x;
            rect.y += table.y;

            if (rect.contains(x, y)) {
                // System.out.println("HitTest: table " + table.getName());
                hit.table = table;
                
                Column col = table.getColumnRect(x, y);
                if (col!=null) {
                    hit.column = col;
                    System.out.println("HitTest: column " + col.name);
                }
            }
        }        
        
        double min_dist = 5;
        Point hitPoint = new Point(x,y);
        for (List<ForeignKey> fkList:model.foreignKeys.values()) {
            for(ForeignKey fk:fkList) {
                Point lastPoint = null;
                int lineSection = -2;
                for (Point p:fk.linePoints) {
                    lineSection++;
                    if (lastPoint!=null) {
                        double dist = distanceToLine(lastPoint, p, hitPoint);
//                        if (fk.toTableName.equals("actor")) {
//                            if (fk.fromTableName.equals("po_related_transaction")) {
//                                // dist = distanceToLine(new Point(2,0), new Point(4,2), new Point (10,0));
//                            }
//                        }
                        if (dist<min_dist) {
                            min_dist = dist;
                            hit.hitForeignKey = fk;
                            hit.foreignKeyLineSection = lineSection;
                            System.out.println("HitTest: link 2: dist to line: " + dist + " " + fk.fromTableName + " -> " + fk.toTableName + " section:" + hit.foreignKeyLineSection);
                            int current_point_idx = -1;
                            int point_idx = -1;
                            for (Point cp:fk.linePoints) {
                                current_point_idx++;
                                dist = distanceToPoint(cp, hitPoint);                                
                                System.out.println("HitTest: link 2a: dist to point: " + dist);
                                if (dist<5) {
                                    point_idx = current_point_idx;
                                    min_dist = dist;
                                    hit.controlPoint = cp;
                                    System.out.println("HitTest: link 3: " + fk.fromTableName + " -> " + fk.toTableName + " controlPoint:" + cp.toString());
                                }
                            }
                            if (point_idx==0) {
                                hit.anchor = fk.startAnchorOffset;
//                                oldAnhorOffset.x = fk.startAnchorOffset.offset.x;
//                                oldAnhorOffset.y = fk.startAnchorOffset.offset.y;
                            }
                            else {
                                if (point_idx==fk.linePoints.size()-1) {
                                    hit.anchor = fk.endAnchorOffset;
//                                    oldAnhorOffset.x = fk.endAnchorOffset.offset.x;
//                                    oldAnhorOffset.y = fk.endAnchorOffset.offset.y;
                                }
                            }
                        }
                    }
                    lastPoint = p;                            
                }
            }
        }
        return hit;    
    }    
    
    double distanceToPoint(Point p0, Point p1) {
        double vx = p1.x-p0.x;
        double vy = p1.y-p0.y;        
        double len = Math.sqrt(Math.pow(vx,2) + Math.pow(vy,2));
        return len;        
    }
    
    double distanceToLine(Point p0, Point p1, Point p) {       
        
//        p0 = new Point(2,0);
//        p1 = new Point(4,2);
//        p = new Point (20,0);
        
        double vx = p1.x-p0.x;
        double vy = p1.y-p0.y;
      
        double nvx = vx;
        double nvy = vy;
        double vlen = Math.sqrt(Math.pow(vx,2) + Math.pow(vy,2));
        
        if (vlen==0) {
            // points have same position
        }
        else {
            nvx /= vlen;
            nvy /= vlen;
        }
        
        double vpx = p.x - p0.x;
        double vpy = p.y - p0.y;
        
        double plen = Math.sqrt(Math.pow(vpx,2) + Math.pow(vpy,2));
        
        double nvpx = vpx / plen;
        double nvpy = vpy / plen;
        
        
        // dot
        double dotP = nvpx*nvx + nvpy*nvy;
        //float projRatio = dotP / length(v);
        double projx = p0.x + (dotP*nvx)*plen;
        double projy = p0.y + (dotP*nvy)*plen;
        
        // 'cap' projected point
        double p0pjDistance = Math.sqrt(Math.pow(p0.x-projx,2) + Math.pow(p0.y-projy,2));
        double p1pjDistance = Math.sqrt(Math.pow(p1.x-projx,2) + Math.pow(p1.y-projy,2));
        
        if (p0pjDistance>vlen || p1pjDistance>vlen) {
            if (p0pjDistance<p1pjDistance) {
                projx = p0.x;
                projy = p0.y;
            }
            else {
                projx = p1.x;
                projy = p1.y;
            }
        }
        // distance calculation
        double distance = Math.sqrt(Math.pow(p.x-projx,2) + Math.pow(p.y-projy,2));
        return distance;
    }
    
    public void refresh() {
        this.invalidate();
        this.revalidate();
        this.repaint();
    }
    
    class HitTestResult {
        Table table;
        Column column;
        ForeignKey hitForeignKey = null;
        int foreignKeyLineSection = -1; 
        Point controlPoint;
        Anchor anchor;
    }
}
