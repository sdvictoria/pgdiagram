/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pgdiagram;

import java.awt.Color;
import java.awt.Point;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author nospoon
 */
public class Model {
    Map<String, Table> tables = new HashMap();
    Map<String, List<ForeignKey>> foreignKeys = new HashMap();
    
    public void add(Table t) {
        tables.put(t.getName(), t);
    }
    
    public Table getTable(String tableName) {
        return tables.get(tableName);
    } 
    
    public ForeignKey addFK(String fromTableName, String[] fromCols, String toTableName, String[] toCols, List<Point> linePoints, Color color) {
        String key = fromTableName;
        
        List<ForeignKey> list = foreignKeys.get(key);
        if (list==null) {
            list = new ArrayList();
            foreignKeys.put(key, list);
        }        
        ForeignKey tl = new ForeignKey(fromTableName, fromCols, toTableName, toCols, list.size());
        if (linePoints==null) {
            linePoints = new ArrayList();            
        }
        while (linePoints.size()<2) {
            linePoints.add(new Point());
        }
        
        tl.linePoints = linePoints;
        tl.color = color;
        list.add(tl);   
        return tl;
    }
    
    public List<ForeignKey> getKFList(String tableName) {
        List<ForeignKey> list = foreignKeys.get(tableName);
        if (list==null) {
            list =  new ArrayList();
        }
        return list;
    }
}
