/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pgdiagram;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

/**
 *
 * @author nospoon
 */
public class FraMain extends JFrame {
    
    CnvDiagram canvas;
    TblTableList tblTables = new TblTableList();
    JTextField txtColor = new JTextField();
    Model model;
    public enum SelectionMode { MOVE, SELECT };
    
    public static SelectionMode selectionMode = SelectionMode.SELECT;    
    
    public static Color backGround = Color.darkGray;
    public static Color colorColumnRowEven = Color.darkGray;
    public static Color colorColumnRowOdd = Color.darkGray.darker();
    public static Color colorColumnFont = Color.white;
    public static Color colorTableHeader = Color.black;
    public static Color colorTableName = Color.green;    
    public static Color colorFont = Color.white;
    
    public FraMain() {        
        
        
        
        this.setBounds(100,100, 1600, 1200);
        this.setLayout(null);
        canvas = new CnvDiagram(this);
        JScrollPane scrCanvas = new JScrollPane(canvas);
        canvas.setBackground(backGround);
        canvas.setPreferredSize(new Dimension(4096, 4096));
        scrCanvas.setBounds(200,0, 1500, 990);
        scrCanvas.setBackground(backGround);
        
        JScrollPane scrTableList = new JScrollPane(tblTables);
        // scrTableList.setBounds(0,0, 200, 700);
        scrTableList.setBounds(0,0, 100, 200);
        tblTables.setBackground(backGround);
        scrTableList.getViewport().setBackground(backGround);
        // tblTables.setPreferredScrollableViewportSize(new Dimension(1500, 1500));
        
        JButton btnLoad = new JButton("Load");
        JButton btnSave = new JButton("Save");        
                                      
        JButton fkAllignAtStart   = new JButton("s-ali");    
        JButton fkAllignAtEnd   = new JButton("e-ali");    
                                
        int xStep = 5;
        int yStep = 1;
       
//        fkAllignAtStart.addActionListener(new AllignFkAncherAction(this, true));
//        fkAllignAtEnd.addActionListener(new AllignFkAncherAction(this, false));
        
         btnLoad.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {       
                loadModel();
            }
        });     
        
        btnSave.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {                     
                if (model!=null) {
                    PgDiagram.toFile(model, PgDiagram.appDir + "/model.pgd");
                }
            }
        });     
        
        txtColor.addKeyListener(new KeyListener() {

            @Override
            public void keyTyped(KeyEvent e) {                
                Color color = null;
                String colorCode = txtColor.getText();
                colorCode = colorCode.toUpperCase();
                colorCode = colorCode.trim();
                colorCode = colorCode.replaceAll("0X", "");
                if (colorCode.length()==8) {
                    colorCode = colorCode.substring(0, 6);
                }
                if (colorCode.length()==6) {
                    try {
                        color  = new Color(Integer.parseInt(colorCode, 16));
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
                if (color!=null) {
//                    if (canvas.hitTestResult!=null && canvas.hitTestResult.hitForeignKey!=null) {
//                        canvas.hitTestResult.hitForeignKey.color = color;
//                    }
//                    canvas.refresh();
                }
            }

            @Override
            public void keyPressed(KeyEvent e) {}

            @Override
            public void keyReleased(KeyEvent e) {}
        });
        
        btnLoad.setBounds(0,1000, 90, 20);
        btnSave.setBounds(100,1000, 90, 20);
        txtColor.setBounds(200,1000, 90, 20);
        fkAllignAtStart.setBounds(300, 1020, 90, 20);        
        fkAllignAtEnd.setBounds(600, 1020, 90, 20);
        
        addToContentPane(scrTableList, scrCanvas);    
        addToContentPane(btnLoad, btnSave, txtColor);               
        addToContentPane(fkAllignAtStart, fkAllignAtEnd);
        
        this.setVisible(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);        
    }
    
    public void loadModel() {
        String modelFileName = PgDiagram.appDir + "/model.pgd";
        System.out.println("Reading from " + modelFileName);  
        model = PgDiagram.toModel(modelFileName);
        // table list

        List<Table> tableList = new ArrayList();
        String[] arr = model.tables.keySet().toArray(new String[0]);
        Arrays.sort(arr);
        for (String tableName:arr) {
            Table table = model.tables.get(tableName);
            tableList.add(table);
        }
        tblTables.setData(tableList);
        canvas.setModel(model);
        canvas.refresh();

    }
    private void addToContentPane(Component... comps) {
        for (Component c:comps) {
            this.getContentPane().add(c);
        }        
    }
      
//    class AllignFkAncherAction implements ActionListener {
//        FraMain fra;
//        boolean start;
//        int xStep;
//        int yStep;
//        AllignFkAncherAction(FraMain fra, boolean start) {            
//            this.fra = fra;
//            this.start = start;
//        }
//
//        @Override
//        public void actionPerformed(ActionEvent e) {
//            if (fra.canvas.hitTestResult!=null) {
//                ForeignKey fk = fra.canvas.hitTestResult.hitForeignKey;
//                if (fk!=null) {                    
//                    if (this.start) {
//                        fk.allignYAtStart();
//                    }
//                    else {
//                        fk.allignYAtEnd();
//                    }                        
//                    fra.canvas.refresh();
//                }
//            }
//        }
//    }
    
}
